package com.sandhya.instagram.fragment;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.sandhya.instagram.R;
import com.sandhya.instagram.adapter.HistoryAccountAdapter;
import com.sandhya.instagram.adapter.StoryAdapter;
import com.sandhya.instagram.model.HistoryAccountModel;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    public HomeFragment() {
        // Required empty public constructor
    }
    Toolbar toolbarHome;
    TextView txtInstagram;

    RecyclerView recyclerStory;

    ArrayList<HistoryAccountModel> sModel = new ArrayList<>();
    StoryAdapter storyAdapter;
    HistoryAccountModel model = null;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        toolbarHome = view.findViewById(R.id.toolbarHome);
        txtInstagram = view.findViewById(R.id.txtInstagram);



        ImageView imgMyStory = view.findViewById(R.id.imgMyStory);
        TextView txtMyTitle = view.findViewById(R.id.txtMyTitle);
        txtMyTitle.setText("Sandhya Gautam");
        Glide.with(getActivity()).load("https://th.bing.com/th/id/OIP.WIsBVj2VuK8o14hZUOs8MwHaHw?w=203&h=212&c=7&r=0&o=5&dpr=1.3&pid=1.7").into(imgMyStory);

        recyclerStory = view.findViewById(R.id.recyclerStory);
        LinearLayoutManager manager = new LinearLayoutManager(getActivity(),LinearLayoutManager.HORIZONTAL,false);
        recyclerStory.setLayoutManager(manager);
        sModel.add(new HistoryAccountModel(null,null,"Sandhya Gautam","https://th.bing.com/th/id/OIP.WIsBVj2VuK8o14hZUOs8MwHaHw?w=203&h=212&c=7&r=0&o=5&dpr=1.3&pid=1.7",null));
        sModel.add(new HistoryAccountModel(null,null,"Sandhya Gautam","https://th.bing.com/th/id/OIP.rnqM8FdAZl_UTkCSIeH-9QHaHY?w=176&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",null));
        sModel.add(new HistoryAccountModel(null,null,"Sandhya Gautam","https://th.bing.com/th/id/OIP.QHhu5UuBOUz7iX_-I4ctYwHaEy?w=252&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",null));
        sModel.add(new HistoryAccountModel(null,null,"Sandhya Gautam","https://th.bing.com/th/id/OIP.rnqM8FdAZl_UTkCSIeH-9QHaHY?w=176&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",null));
        sModel.add(new HistoryAccountModel(null,null,"Sandhya Gautam","https://th.bing.com/th/id/OIP.QHhu5UuBOUz7iX_-I4ctYwHaEy?w=252&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",null));
        sModel.add(new HistoryAccountModel(null,null,"Sandhya Gautam","https://th.bing.com/th/id/OIP.2FmyoU0UIM3LglMI-ISQZQHaEK?w=289&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7",null));
        storyAdapter = new StoryAdapter(getActivity(),sModel);
        recyclerStory.setAdapter(storyAdapter);

        toolbarHome.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @SuppressLint("NonConstantResourceId")
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                int id = item.getItemId();
                switch (id){
                    case R.id.tpLike:
                        Toast.makeText(getActivity(), "Like", Toast.LENGTH_SHORT).show();
                        BottomSheetDialog dialog = new BottomSheetDialog(getActivity(),R.style.BottomDialog);
                        dialog.setContentView(R.layout.bottom_dialog);
                        dialog.show();
                        break;
                    case R.id.tpChat:
                        Toast.makeText(getActivity(), "Chat", Toast.LENGTH_SHORT).show();
                        break;
                }
                return false;
            }
        });

        txtInstagram.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "Instagram", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

}